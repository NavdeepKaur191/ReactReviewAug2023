import "./App.css";
import Contact from "./Contact.jsx";
import Search from "./Search";
function App() {
  return (
    <div>
      <Search />
    </div>
  );
}

export default App;
