module.exports = {
  plugins: {
    tailwindcss: {},
  },
};
