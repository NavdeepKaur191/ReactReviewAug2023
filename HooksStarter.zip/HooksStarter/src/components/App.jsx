import "./App.css";
import Contact from "./Contact.jsx";
function App() {
  return (
    <div>
      <Contact
        name="Leroy Brown"
        telNumber="(123)-456-7890"
        email="LB35@yahoo.com"
      />
    </div>
  );
}

export default App;
